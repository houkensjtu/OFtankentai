// mini
#include "fvCFD.H"

int main(int argc, char *argv[])
{
	Info << "minimum OpenFOAM program" << endl;

	return 0;
}
